module SlidingPiece
  def

  end
end


module SteppingPiece
  def

  end
end
