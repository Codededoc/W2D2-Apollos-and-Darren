require "piece.rb"
require "modules.rb"

class Knight
  include module SteppingPiece


end
