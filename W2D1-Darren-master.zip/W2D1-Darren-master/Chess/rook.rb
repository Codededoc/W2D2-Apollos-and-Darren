require "piece.rb"
require "modules.rb"

class Rook
  include module SlidingPiece

end
