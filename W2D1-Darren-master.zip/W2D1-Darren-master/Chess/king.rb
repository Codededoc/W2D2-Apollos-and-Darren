require "piece.rb"
require "modules.rb"

class King
  include module SteppingPiece


end
