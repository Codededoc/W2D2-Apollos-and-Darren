require_relative "piece.rb"

class NullPiece < Piece

  def initialize
    @nullpiece
  end

end
