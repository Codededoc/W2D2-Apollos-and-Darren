class Piece

  attr_reader :piece
  def initialize
    @piece = "P"
  end

end
