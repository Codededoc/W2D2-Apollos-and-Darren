require "piece.rb"
require "modules.rb"

class Bishop
  include module SlidingPiece
end
