require "piece.rb"
require "modules.rb"

class Queen
  include module SlidingPiece
end
